import turtle
screen = turtle.Screen()
screen.bgcolor("black")
t = turtle.Turtle()
t.speed(4)
t.speed(10)
radius = 145
t.pensize(4)
# First circle
t.color("dark grey")
t.penup()
t.goto(0, -150)
t.pendown()
t.pensize(19)
t.circle(150)

# Second circle
t.penup()
t.goto(0, -140)
t.pendown()
t.circle(140)

# Go to the center of the circle
t.penup()
t.goto(0, 0)
t.pendown()

# Draw the three spokes of the logo
t.pensize(7)
t.goto(0, radius) 
t.penup()
t.goto(0, 0)
t.pendown()
t.pensize(7)
t.goto(-125, -72) 

t.penup()
t.goto(0, 0)
t.pendown()
t.pensize(7)
t.goto(125, -72) 
# Hide the turtle
t.hideturtle()
t.penup()
t.goto(-115,-180)
t.pendown()
t.write("MERCEDES BENZ",font=("times new roman",20,"bold"),align="centre")

